# PAUSE ROUTINE LOAD

## example

1. Pause routine load job for test 1

    ```sql
    PAUSE ROUTINE LOAD FOR test1;
    ```

## keyword

PAUSE,ROUTINE,LOAD
