# SHOW DATABASES

## description

This statement is used to display the currently visible db

Syntax：

```sql
SHOW DATABASES;
```

## keyword

SHOW,DATABASES
