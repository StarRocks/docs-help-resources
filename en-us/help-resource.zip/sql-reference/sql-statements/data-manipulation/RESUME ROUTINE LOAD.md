# RESUME ROUTINE LOAD

## example

1. Resume routine load job for test 1

```sql
    RESUME ROUTINE LOAD FOR test1;
```

## keyword

RESUME,ROUTINE,LOAD
