# STOP ROUTINE LOAD

## example

1. Stop the routine import job named test1.

```sql
STOP ROUTINE LOAD FOR test1;
```

## keyword

STOP,ROUTINE,LOAD
