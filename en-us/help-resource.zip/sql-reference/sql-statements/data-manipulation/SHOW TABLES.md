# SHOW TABLES

## description

This statement is used to display all tables in the current db

Syntax：

```sql
SHOW TABLES;
```

## keyword

SHOW,TABLES
