# SHOW ROUTINE LOAD TASK

## example

1. Displays the subtask information of the routine import task named test1.

    ```sql
    SHOW ROUTINE LOAD TASK WHERE JobName = "test1";
    ```

## keyword

SHOW,ROUTINE,LOAD,TASK
