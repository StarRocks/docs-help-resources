# SHOW ROLES

## description

This statement is used to show all the information about the created roles, containing roles' names, users included and their permissions.

Syntax:

```sql
SHOW ROLES;
```

## example

1. View the created roles

    ```sql
    SHOW ROLES;
    ```

## keyword

SHOW,ROLES
