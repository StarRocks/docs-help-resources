# CREATE ROLE

## description

This statement allows users to create a role.

 Syntax:

```sql
CREATE ROLE role1;
```

It creates a role with no permission which could be added to the role though "GRANT" command.  

## example

 1. Create a role

  ```sql
  CREATE ROLE role1;
  ```

## keyword

CREATE, ROLE
