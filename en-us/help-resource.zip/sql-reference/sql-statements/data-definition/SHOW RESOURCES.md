# SHOW RESOURCES

## description

This statement is used to show the resources that the users have permissions to use. Ordinary users can only use the resources they have permission to use, while root or admin users can show all resources.

Syntax:

```sql
SHOW RESOURCES
```

## keyword

SHOW RESOURCES
