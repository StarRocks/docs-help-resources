# DROP INDEX

## description

This statement is used to drop a specified index on a table. Currently, only bitmap index is supported in this version.

Syntax:

```sql
DROP INDEX index_name ON [db_name.]table_name;
```

## keyword

DROP,INDEX
