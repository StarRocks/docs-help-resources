# SHOW PLUGINS

## description

This statement is used to view the installed plugins.

Syntax:

```sql
SHOW PLUGINS;
```

This command will display all built-in plugins and custom plugins.

## example

1. Show the installed plugins:

    ```sql
    SHOW PLUGINS;
    ```

## keyword

SHOW PLUGINS
