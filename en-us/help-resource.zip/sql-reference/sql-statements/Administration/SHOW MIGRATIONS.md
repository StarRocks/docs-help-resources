# SHOW MIGRATIONS

## description

This statement is used to view the progress of database migration.

Syntax:

```sql
SHOW MIGRATIONS
```

## keyword

```sql
SHOW,MIGRATIONS
```
