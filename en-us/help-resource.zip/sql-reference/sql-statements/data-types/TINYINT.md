# TINYINT

## description

TINYINT

1 byte signed integer, range [-128, 127]

## keyword

TINYINT
