# BIGINT

## description

BIGINT

BIGINT 8-byte signed integer, range[-9223372036854775808, 9223372036854775807]

## keyword

BIGINT
