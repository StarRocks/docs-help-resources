# LARGEINT

## description

LARGEINT

16 byte signed integer, range [-2^127 + 1 ~ 2^127 - 1]

## keyword

LARGEINT
