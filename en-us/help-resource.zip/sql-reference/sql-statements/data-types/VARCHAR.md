# VARCHAR

## description

VARCHAR(M)

A variable length string, M represents the length of a variable length string. The range of M is 1-65533

## keyword

VARCHAR
