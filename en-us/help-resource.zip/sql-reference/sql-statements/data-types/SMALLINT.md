# SMALLINT

## description

SMALLINT

2-byte signed integer, range [-32768, 32767]

## keyword

SMALLINT
