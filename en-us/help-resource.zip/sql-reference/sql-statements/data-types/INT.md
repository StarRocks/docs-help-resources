# INT

## description

INT

4-byte signed integer, range [-2147483648, 2147483647]

## keyword

INT
