# BOOLEAN

## description

BOOL, BOOLEAN

Like TINYINT, 0 stands for false and 1 for true.

## keyword

BOOLEAN
