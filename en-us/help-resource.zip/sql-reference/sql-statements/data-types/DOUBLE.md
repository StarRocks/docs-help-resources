# DOUBLE

## description

DOUBLE

8-byte floating point number

## keyword

DOUBLE
