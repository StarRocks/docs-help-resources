# CHAR

## description

CHAR(M)

A fixed-length string, M represents the length of a fixed-length string. The range of M is 1-255.

## keyword

CHAR
