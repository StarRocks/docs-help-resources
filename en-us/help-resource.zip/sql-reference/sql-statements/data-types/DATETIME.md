# DATETIME

## description

DATETIME

Date and time type, value range is ['0000-01-01 00:00:00','9999-12-31 23:59:59'].

The form of printing is 'YYYY-MM-DD HH:MM:SS'

## keyword

DATETIME
