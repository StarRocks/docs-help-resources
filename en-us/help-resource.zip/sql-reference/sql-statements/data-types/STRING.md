# STRING

## description

STRING

A variable length string, maximum length is 65533 byte

## keyword

STRING
