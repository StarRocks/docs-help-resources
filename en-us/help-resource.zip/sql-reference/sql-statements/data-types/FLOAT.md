# FLOAT

## description

FLOAT

4-byte floating point number

## keyword

FLOAT
