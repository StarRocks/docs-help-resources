# DECIMAL

## description

DECIMAL(M[,D])

高精度定点数，M代表一共有多少个有效数字(precision)，D代表小数点后最多有多少数字(scale)

M的范围是[1,27], D的范围[1, 9], 另外，M必须要大于等于D的取值。默认的D取值为0

## keyword

DECIMAL
