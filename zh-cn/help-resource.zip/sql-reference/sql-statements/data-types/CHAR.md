# CHAR

## description

CHAR(M)

定长字符串，M代表的是定长字符串的长度。M的范围是1-255

## keyword

CHAR
