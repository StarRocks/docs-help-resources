# LARGEINT

## description

LARGEINT

16字节有符号整数，范围[-2^127 + 1 ~ 2^127 - 1]

## keyword

LARGEINT
