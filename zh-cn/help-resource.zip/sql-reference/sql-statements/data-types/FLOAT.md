# FLOAT

## description

FLOAT

4字节浮点数

## keyword

FLOAT
