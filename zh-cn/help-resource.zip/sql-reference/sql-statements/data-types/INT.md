# INT

## description

INT

4字节有符号整数，范围[-2147483648, 2147483647]

## keyword

INT
