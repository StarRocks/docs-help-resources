# DATETIME

## description

DATETIME

日期时间类型，取值范围是['0000-01-01 00:00:00', '9999-12-31 23:59:59'].

打印的形式是'YYYY-MM-DD HH:MM:SS'

## keyword

DATETIME
