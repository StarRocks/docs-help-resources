# TINYINT

## description

TINYINT

1字节有符号整数，范围[-128, 127]

## keyword

TINYINT
