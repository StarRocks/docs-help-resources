# BOOLEAN

## description

BOOL, BOOLEAN

与TINYINT一样，0代表false，1代表true

## keyword

BOOLEAN
