# STRING

## description

STRING

变长字符串，最大长度65533字节

## keyword

STRING
