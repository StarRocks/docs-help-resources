# DOUBLE

## description

DOUBLE

8字节浮点数

## keyword

DOUBLE
