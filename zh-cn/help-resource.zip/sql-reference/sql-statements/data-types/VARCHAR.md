# VARCHAR

## description

VARCHAR(M)

变长字符串，M 代表的是变长字符串的长度。M 的范围是1-65533。
> 65535（行最大值）- 2（长度标识位，记录实际数据长度）= 65533 。

## keyword

VARCHAR
