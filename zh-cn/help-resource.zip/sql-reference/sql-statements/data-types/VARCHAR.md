# VARCHAR

## description

VARCHAR(M)

变长字符串，M代表的是变长字符串的长度。M的范围是1-65533

## keyword

VARCHAR
