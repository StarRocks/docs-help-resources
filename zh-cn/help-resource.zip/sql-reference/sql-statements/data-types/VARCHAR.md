# VARCHAR

## description

VARCHAR(M)

变长字符串，M代表的是变长字符串的长度。M的范围是1-1048576（自2.1版本开始，M的范围为1-1048576；2.1之前的版本的M范围为1-65533)。

## keyword

VARCHAR
