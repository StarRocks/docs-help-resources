# SMALLINT

## description

SMALLINT

2字节有符号整数，范围[-32768, 32767]

## keyword

SMALLINT
