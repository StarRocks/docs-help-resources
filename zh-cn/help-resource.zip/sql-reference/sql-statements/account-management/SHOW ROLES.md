# SHOW ROLES

## 功能

该语句用于展示所有已创建的角色信息，包括角色名称，包含的用户以及权限。

## 语法

```sql
SHOW ROLES;
```

## 示例

1. 查看已创建的角色：

    ```sql
    SHOW ROLES;
    ```

## 关键字(keywords)

SHOW, ROLES
