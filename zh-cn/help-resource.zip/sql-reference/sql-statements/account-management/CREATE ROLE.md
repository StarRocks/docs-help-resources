# CREATE ROLE

## description

该语句为：用户去创建一个角色

 语法：

```sql
CREATE ROLE role1;
```

 该语句创建一个无权限的角色，可以后续通过 GRANT 命令赋予该角色权限。

## example

 1. 创建一个角色

  ```sql
  CREATE ROLE role1;
  ```

## keyword

CREATE, ROLE
