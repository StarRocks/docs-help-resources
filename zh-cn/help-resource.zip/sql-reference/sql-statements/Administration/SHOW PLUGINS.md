# SHOW PLUGINS

## description

该语句用于展示已安装的插件。

语法:

```sql
SHOW PLUGINS;
```

该命令会展示所有用户安装的和系统内置的插件。

## example

1. 展示已安装的插件：

    ```sql
    SHOW PLUGINS;
    ```

## keyword

SHOW PLUGINS
