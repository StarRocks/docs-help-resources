# SHOW MIGRATIONS

## 功能

该语句用于查看数据库迁移的进度。

## 语法

```sql
SHOW MIGRATIONS；
```

## 关键字(keywords)

```sql
SHOW，MIGRATIONS
```
