# SHOW FULL COLUMNS

## description

该语句用于指定表的列信息

语法：

```sql
SHOW FULL COLUMNS FROM tbl;
```

## example

1. 查看指定表的列信息

    ```sql
    SHOW FULL COLUMNS FROM tbl;
    ```

## keyword

SHOW,TABLE,STATUS
