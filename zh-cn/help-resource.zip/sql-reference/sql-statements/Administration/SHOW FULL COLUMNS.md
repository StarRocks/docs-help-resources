# SHOW FULL COLUMNS

## 功能

该语句用于查看指定表的列信息。

## 语法

```sql
SHOW FULL COLUMNS FROM tbl;
```

## 示例

1. 查看指定表的列信息。

    ```sql
    SHOW FULL COLUMNS FROM tbl;
    ```

## 关键字(keywords)

SHOW，TABLE，STATUS
