# PAUSE ROUTINE LOAD

## example

1. 暂停名称为 test1 的例行导入作业。

    ```sql
    PAUSE ROUTINE LOAD FOR test1;
    ```

## keyword

PAUSE,ROUTINE,LOAD
