# SHOW TABLES

## 功能

该语句用于展示当前 db 下所有的 table。

## 语法

```sql
SHOW TABLES;
```
