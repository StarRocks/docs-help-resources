# SHOW DYNAMIC PARTITION TABLES

## description

该语句用于展示当前db下所有的动态分区表状态

语法：

```sql
SHOW DYNAMIC PARTITION TABLES [FROM db_name];
```

## example

1. 展示数据库 database 的所有动态分区表状态

```sql
SHOW DYNAMIC PARTITION TABLES FROM database;
```

## keyword

SHOW,DYNAMIC,PARTITION,TABLES
