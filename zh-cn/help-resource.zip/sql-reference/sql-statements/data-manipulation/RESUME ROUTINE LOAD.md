# RESUME ROUTINE LOAD

## example

1. 恢复名称为 test1 的例行导入作业。

```sql
    RESUME ROUTINE LOAD FOR test1;
```

## keyword

RESUME,ROUTINE,LOAD
