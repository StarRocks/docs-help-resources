# SHOW ROUTINE LOAD TASK

## 功能

查看 routine load 任务的子任务信息。

## 示例

1. 展示名为 test1 的例行导入任务的子任务信息。

    ```sql
    SHOW ROUTINE LOAD TASK WHERE JobName = "test1";
    ```
