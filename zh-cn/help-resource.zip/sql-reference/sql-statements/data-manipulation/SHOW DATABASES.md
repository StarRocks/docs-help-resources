# SHOW DATABASES

## description

该语句用于展示当前可见的 db

语法：

```sql
SHOW DATABASES;
```

## keyword

SHOW,DATABASES
