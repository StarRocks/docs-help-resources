# SHOW DATABASES

## 功能

该语句用于展示当前可见的数据库 db。

## 语法

```sql
SHOW DATABASES;
```

## 关键字(keywords)

SHOW,DATABASES
