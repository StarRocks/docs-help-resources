# STOP ROUTINE LOAD

## example

1. 停止名称为 test1 的例行导入作业。

```sql
STOP ROUTINE LOAD FOR test1;
```

## keyword

STOP,ROUTINE,LOAD
