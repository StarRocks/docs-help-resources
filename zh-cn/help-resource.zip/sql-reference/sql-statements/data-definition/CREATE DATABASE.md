# CREATE DATABASE

## description

该语句用于新建数据库（database）

语法：

```sql
CREATE DATABASE [IF NOT EXISTS] db_name;
```

## example

1. 新建数据库 db_test

    ```sql
    CREATE DATABASE db_test;
    ```

## keyword

CREATE,DATABASE
