# SHOW RESOURCES

## 功能

用于展示用户有使用权限的资源。普通用户仅能展示有使用权限的资源，root 或 admin 用户会展示所有的资源。

## 语法

```sql
SHOW RESOURCES;
```
