# DROP INDEX

## 功能

该语句用于从一个表中删除指定名称的索引，目前仅支持 bitmap 索引。

## 语法

```sql
DROP INDEX index_name ON [db_name.]table_name;
```

## 关键字(keywords)

DROP, INDEX
