# STDDEV_SAMP

## 功能

返回 expr 表达式的样本标准差

## 语法

```Haskell
STDDEV_SAMP(expr)
```

## 参数说明

`epxr`: 被选取的表达式

## 返回值说明

返回值为数值类型

## 示例

```plain text
MySQL > select stddev_samp(scan_rows)
from log_statis
group by datetime;
+--------------------------+
| stddev_samp(`scan_rows`) |
+--------------------------+
|        2.372044195280762 |
+--------------------------+
```

## 关键词

STDDEV_SAMP, STDDEV, SAMP
