# JSON_EXISTS

## 功能

查询 JSON 对象中指定路径（`json_path`）是否存在满足特定条件的值。如果值存在，则返回 `1`；如果值不存在，则返回 `0`。

## 语法

```Plain Text
JSON_EXISTS(json_object_expr, json_path)
```

## 参数说明

- `json_object_expr`：JSON 对象的表达式，可以是 JSON 类型的列，或者 PARSE_JSON 等 JSON 函数构造的 JSON 对象。

- `json_path`: 查询 JSON 对象时的路径。支持的数据类型为字符串。StarRocks 支持的 JSON Path 的语法，请参见 [JSON Path 语法](../json-functions-and-operators.md/#JSON%Path)。

## 返回值说明

返回 BOOLEAN 类型的值。

## 示例

示例一：查询 JSON 对象中路径表达式（`'$.a.b'` ）指定的值。由于值存在，因此返回 `1`。

```Plain Text
mysql> SELECT JSON_EXISTS(PARSE_JSON('{"a": {"b": 1}}'), '$.a.b') ;
       -> 1
```

示例二：查询 JSON 对象中路径表达式（`'$.a.c'` ）指定的值。由于值不存在，因此返回 `0`。

```Plain Text
mysql> SELECT JSON_EXISTS(PARSE_JSON('{"a": {"b": 1}}'), '$.a.c') ;
       -> 0
```

示例三：查询 JSON 对象中路径表达式 `'$.a[2]'` （a 数组的第 2 个元素）指定的值。由于 a 数组中存在第 2 个元素，因此返回 `1`。

```Plain Text
mysql> SELECT JSON_EXISTS(PARSE_JSON('{"a": [1,2,3]}'), '$.a[2]') ;
       -> 1
```

示例四：查询 JSON 对象中路径表达式 `'$.a[3]'` （a 数组的第 3 个元素）指定的值。由于 a 数组中不存在第 3 个元素，因此返回 `0`。

```Plain Text
mysql> SELECT JSON_EXISTS(PARSE_JSON('{"a": [1,2,3]}'), '$.a[3]') ;
       -> 0
```
