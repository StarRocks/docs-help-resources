# year

## description

### Syntax

```Haskell
INT YEAR(DATETIME date)
```

返回date类型的year部分，范围从1000-9999

参数为Date或者Datetime类型

## 返回值说明

返回INT类型的值，范围1000-9999。
此函数会对整数和字符串类型的输入进行隐式转换，如果未能从输入中解析出合法年份，如 `year('string')`，则返回NULL。如果输入数据类型非法，如 `year(3.1415)`，则返回报错。

## 示例

示例1：返回'1987-01-01'中的年份`1987`。

```Plain Text

MySQL > select year('1987-01-01');
+--------------------+
| year('1987-01-01') |
+--------------------+
|               1987 |
+--------------------+
1 row in set (0.00 sec)
```

示例2：返回当前年份。

```Plain Text
MySQL > select year(now());
+-------------+
| year(now()) |
+-------------+
|        2022 |
+-------------+
1 row in set (0.00 sec)
```

## keyword

YEAR
