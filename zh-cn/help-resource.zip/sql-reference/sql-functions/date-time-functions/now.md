# now

## description

### Syntax

`DATETIME NOW()`

获得当前的时间，以Datetime类型返回

## example

```Plain Text
MySQL > select now();
+---------------------+
| now()               |
+---------------------+
| 2019-05-27 15:58:25 |
+---------------------+
```

## keyword

NOW
